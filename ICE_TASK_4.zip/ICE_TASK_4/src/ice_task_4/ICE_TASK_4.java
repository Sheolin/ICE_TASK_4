/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ice_task_4;

import javax.swing.*;

public class ICE_TASK_4 {

    public static void main(String[] args) {
        int age = Integer.parseInt(JOptionPane.showInputDialog("Please enter age"));
        if (age < 18) {
            JOptionPane.showMessageDialog(null, "Access denied");
        } else if (age >= 18 && age <= 35) {
            String gender = JOptionPane.showInputDialog("Enter gender");
            if (gender == "male") {
                int people = Integer.parseInt(JOptionPane.showInputDialog("Enter nunber of guests"));
                int amount = people * 10;
                JOptionPane.showMessageDialog(null, "Amount due : R" + amount);
            } else if (gender == "female") {
                JOptionPane.showMessageDialog(null, "Free entry");
            }
        } else if (age > 35) {
            JOptionPane.showMessageDialog(null, "Access denied");
        }
    }

}
